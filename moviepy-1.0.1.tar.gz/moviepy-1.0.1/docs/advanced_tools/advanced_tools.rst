.. _advancedtools:

Advanced tools
===============

This section will briefly present the submodule ``moviepy.video.tools`` that can help you edit videos. It's not ready yet, see :ref:`ref_videotools` (the same in more complete and more technical) instead.

Tracking
~~~~~~~~~

Cuts
~~~~~~~~

Subtitles
~~~~~~~~~~

Credits
~~~~~~~~