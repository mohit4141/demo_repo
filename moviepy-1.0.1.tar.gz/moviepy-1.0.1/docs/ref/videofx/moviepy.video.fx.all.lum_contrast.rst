moviepy.video.fx.all.lum_contrast
=================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: lum_contrast