package com.rbs.customers;

import java.io.Serializable;

public class Professional implements Serializable{
private static final long serialVersionUID= -421354854254567461L;

String str_Name, str_CompanyName;
int employee_id;

public String getStr_Name() {
	return str_Name;
}
public void setStr_Name(String str_Name) {
	this.str_Name = str_Name;
}
public String getStr_CompanyName() {
	return str_CompanyName;
}
public void setStr_CompanyName(String str_CompanyName) {
	this.str_CompanyName = str_CompanyName;
}
public int getEmployee_id() {
	return employee_id;
}
public void setEmployee_id(int employee_id) {
	this.employee_id = employee_id;
}

}
