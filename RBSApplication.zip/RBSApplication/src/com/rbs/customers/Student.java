package com.rbs.customers;

import java.io.Serializable;
import java.util.Scanner;

public class Student implements Serializable {
	private static final long serialVersionUID = -4452146213684646L;
	String strStudentName, strRollNo,strStudentID;
	public String getStrStudentName() {
//		System.out.print("Enter your Name:");
//		strStudentName = new Scanner(System.in);
		return strStudentName;
		
	}
	public void setStrStudentName(String strStudentName) {
		this.strStudentName = strStudentName;
	}
	public String getStrRollNo() {
		return strRollNo;
	}
	public void setStrRollNo(String strRollNo) {
		this.strRollNo = strRollNo;
	}
	public String getStrStudentID() {
		return strStudentID;
	}
	public void setStrStudentID(String strStudentID) {
		this.strStudentID = strStudentID;
	}
	
	
}
