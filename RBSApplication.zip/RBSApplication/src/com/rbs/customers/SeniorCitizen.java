package com.rbs.customers;

import java.io.Serializable;

public class SeniorCitizen implements Serializable{
	
	private static final  long serialVersionUID= -5445763543574452L;
	
	String str_Name,str_Phone;
	int int_Age;
	public String getStr_Name() {
		return str_Name;
	}
	public void setStr_Name(String str_Name) {
		this.str_Name = str_Name;
	}
	public int getInt_Age() {
		return int_Age;
	}
	public void setInt_Age(int int_Age) {
		this.int_Age = int_Age;
	}
	public String getStr_Phone() {
		return str_Phone;
	}
	public void setStr_Phone(String str_Phone) {
		this.str_Phone = str_Phone;
	}
	

}
