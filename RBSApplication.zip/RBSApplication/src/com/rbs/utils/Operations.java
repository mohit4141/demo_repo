package com.rbs.utils;

public interface Operations {

	public void openAccount();
	public void Deposit();
	public void Withdraw();
	public void openFD();
	
}
