package com.rbs.main;

import java.util.Scanner;

import com.rbs.app.Application;
import com.rbs.banks.AXIS;
import com.rbs.banks.HDFC;
import com.rbs.banks.ICICI;
import com.rbs.banks.SC;
import com.rbs.customers.Professional;
import com.rbs.customers.SeniorCitizen;
import com.rbs.customers.Student;
import com.rbs.utils.Operations;

public class Banking {
	
	public final String strDisplayCustomerType="1. Student\n2. Senior Citizen\n3. Professional";
	public final String strBankType="1. ICICI\n2. HDFC\n3. AXIS\n4. SC";
	public final String strOptions="1. Open Account\n 2. Deposit \n 3. Withdraw\n 4. Open Fixed Deposit\n";
	Application mApplication;
	Student stud= null;
	SeniorCitizen sen= null;
	Professional pro= null;
	String bankname;
	int mChoice, mBankChoice, mOperationChoice;
	
	public static void main(String[] args) {
		Banking mBanking = new Banking();
		mBanking.mApplication = Application.getInstance();
		mBanking.CustomerMenu(mBanking, mBanking.mApplication);
	}
	public void CustomerMenu(Banking mBanking, Application mApplication) {
		mApplication.setStatus(true);
		mApplication.displayMessage(strDisplayCustomerType);
		mChoice = mApplication.getScannerInstance().nextInt();
		if(mChoice > 0)
			if(mChoice==1)
			{
				
				stud= new Student();
//				strStudentName=mApplication.getScannerInstance().next();
				System.out.println("Enter Name :");
				stud.setStrStudentName(mApplication.getScannerInstance().next());
//				System.out.println(stud.getStrStudentID());
				System.out.println("Enter Roll No : ");
				stud.setStrRollNo(mApplication.getScannerInstance().next());
				System.out.println("Enter SID: ");
				stud.setStrStudentID(mApplication.getScannerInstance().next());
			}
			
			if(mChoice==2) {
				sen=new SeniorCitizen();
				System.out.println("Enter Name :");
				sen.setStr_Name(mApplication.getScannerInstance().next());
				System.out.println("Enter Age :");
				sen.setInt_Age(mApplication.getScannerInstance().nextInt());
				System.out.println("Enter Phone No :");
				sen.setStr_Phone(mApplication.getScannerInstance().next());
				
			}
			
			if(mChoice==3) {
				pro=new Professional();
				System.out.println("Enter Name :");
				pro.setStr_Name(mApplication.getScannerInstance().next());
				System.out.println("Enter Employee Id :");
				pro.setEmployee_id(mApplication.getScannerInstance().nextInt());
				System.out.println("Enter Company Name :");
				pro.setStr_CompanyName(mApplication.getScannerInstance().next());
				
			}
			
			
			mBanking.SelectBankMenu(mBanking, mBanking.mApplication);		
	}
	public void SelectBankMenu(Banking mBanking, Application Application) {
		mApplication.setStatus(true);
		mApplication.displayMessage(strBankType);
		mBankChoice = mApplication.getScannerInstance().nextInt();
		if(mBankChoice > 0)
			if (mChoice==1) {
				ICICI bname= new ICICI();
				bankname="ICICI";
				
			}
			if (mChoice==2) {
				HDFC bname= new HDFC();
				bankname="HDFC";
			}
			if (mChoice==3) {
				AXIS bname= new AXIS();
				bankname="AXIS";
			}
			if (mChoice==4) {
				SC bname= new SC();
				bankname="SC";
			}
		
			
			mBanking.SelectOperationMenu(mBanking, mBanking.mApplication);
	}
	
	public void SelectOperationMenu(Banking mBanking, Application Application) {
		mApplication.setStatus(true);
		mApplication.displayMessage(strOptions);
		mOperationChoice = mApplication.getScannerInstance().nextInt();
		if (mChoice==1) {
			switch(bankname) {
			case "ICICI":
				ICICI objnew=new ICICI();
			objnew.openAccount(stud);
			break;
			
			case "HDFC":
				HDFC objhdfc=new HDFC();
				objhdfc.openAccount();
			}
		}
		
	}
	
	
	
}
