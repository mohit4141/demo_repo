package com.rbs.banks;

import com.rbs.customers.Student;
import com.rbs.utils.RBI;

public class HDFC extends RBI {
	@Override
	public void Withdraw() {
		super.Withdraw();
	}
	@Override
	public void Deposit() {
		super.Deposit();
	}
	@Override
	public void openFD() {
		super.openFD();
	}
	public void openAccount(Object obj) {
		super.openAccount();
		if (obj instanceof Student ) {
			Student stud = (Student) obj;
		
		System.out.println("The account has been opened for"+ stud.getStrStudentName() +"! Thank You for Choosing ICICI. ");
		}
	}
}