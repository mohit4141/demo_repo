package com.rbs.banks;

import com.rbs.utils.RBI;

public class AXIS extends RBI {
	@Override
	public void Withdraw() {
		super.Withdraw();
	}
	@Override
	public void Deposit() {
		super.Deposit();
	}
	@Override
	public void openFD() {
		super.openFD();
	}
	@Override
	public void openAccount() {
		super.openAccount();
		System.out.println("The account has been opened ! Thank You for Choosing AXIS. ");
	}
}
